module switch(in,in0,in1,in2,in3,in4,in5,in6,out0,out1,out2,out3,out4,out5,out6);
input [7:0] in;
input in0,in1,in2,in3,in4,in5,in6;
output  reg out0,out1,out2,out3,out4,out5,out6;
always @(*)
	begin
	if(in==8'b11110000) begin out0=1'b0;out1=1'b0;out2=1'b0;out3=1'b0;out4=1'b0;out5=1'b0;out6=1'b0;end
	else begin out0=in0;out1=in1;out2=in2;out3=in3;out4=in4;out5=in5;out6=in6;end
	end
endmodule
		