module seg_display(
    input         clk,        
    input         out_en,     
    input  [7:0]  data_in,    
    output        seg_qa,     
    output        seg_qb,     
    output        seg_qc,     
    output        seg_qd,     
    output        seg_qe,     
    output        seg_qf,     
    output        seg_qg,     
    output [7:0]  bit_sel_out 
);

wire [7:0] data_reg_cout;
data_reg u_data_reg(
    .clk  (clk),
    .en   (out_en),  
    .cout (data_reg_cout)
);

wire [1:0] counter_out;
counter u_counter(
    .clk (clk),
    .out (counter_out)
);

wire [3:0] bit_sel_out1;
bit_sel u_bit_sel(
    .q     (counter_out),   
    .in    (data_reg_cout), 
    .out1  (bit_sel_out1),  
    .s     (bit_sel_out)    
);


wire seg_qa_w, seg_qb_w, seg_qc_w, seg_qd_w, seg_qe_w, seg_qf_w, seg_qg_w;
seg u_seg(
    .in  (bit_sel_out1), 
    .qa  (seg_qa_w),
    .qb  (seg_qb_w),
    .qc  (seg_qc_w),
    .qd  (seg_qd_w),
    .qe  (seg_qe_w),
    .qf  (seg_qf_w),
    .qg  (seg_qg_w)
);


switch u_switch(
    .in    (8'b00000000),
    .in0   (seg_qa_w),
    .in1   (seg_qb_w),
    .in2   (seg_qc_w),
    .in3   (seg_qd_w),
    .in4   (seg_qe_w),
    .in5   (seg_qf_w),
    .in6   (seg_qg_w),
    .out0  (seg_qa),  
    .out1  (seg_qb),  
    .out2  (seg_qc),  
    .out3  (seg_qd),  
    .out4  (seg_qe),  
    .out5  (seg_qf),  
    .out6  (seg_qg)   
);

endmodule