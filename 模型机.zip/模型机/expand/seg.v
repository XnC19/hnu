module seg(in, qa, qb, qc, qd, qe, qf, qg) ;
input [3:0]in;
output qa, qb, qc, qd, qe, qf, qg;
reg qa=0,qb=0,qc=0,qd=0,qe=0,qf=0,qg=0;
always@ (*)
begin
case (in)
4'b0000:begin qa=1; qb=1;qc=1;qd=1;qe=1;qf=1;qg=0;end//0
4'b0001:begin qa=0; qb=1;qc=1;qd=0;qe=0;qf=0;qg=0;end//1
4'b0010:begin qa=1; qb=1;qc=0;qd=1;qe=1; qf=0;qg=1;end //2
4'b0011:begin qa=1; qb=1; qc=1;qd=1; qe=0;qf=0;qg=1;end//3
4'b0100:begin qa=0; qb=1; qc=1; qd=0; qe=0; qf=1;qg=1;end//4
4'b0101:begin qa=1; qb=0;qc=1;qd=1;qe=0;qf=1;qg=1;end//5
4'b0110:begin qa=1; qb=0;qc=1;qd=1;qe=1;qf=1;qg=1;end//6
4'b0111:begin qa=1; qb=1;qc=1;qd=0;qe=0;qf=0;qg=0;end//7
4'b1000:begin qa=1; qb=1;qc=1;qd=1;qe=1;qf=1;qg=1;end//8
4'b1001:begin qa=1;qb=1;qc=1;qd=1;qe=0;qf=1;qg=1;end//9
4'b1010:begin qa=1;qb=1;qc=1;qd=0;qe=1;qf=1;qg=1;end//A
4'b1011:begin qa=0; qb=0;qc=1;qd=1;qe=1; qf=1;qg=1;end//B
4'b1100:begin qa=1; qb=0; qc=0;qd=1; qe=1; qf=1;qg=0;end//C
4'b1101:begin qa=0; qb=1;qc=1;qd=1;qe=1;qf=0;qg=1;end//d
4'b1110:begin qa=1; qb=0;qc=0;qd=1;qe=1;qf=1;qg=1;end//E
4'b1111:begin qa=1;qb=0;qc=0;qd=0;qe=1;qf=1;qg=1;end//F
endcase
end
endmodule