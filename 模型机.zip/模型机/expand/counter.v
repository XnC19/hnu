module counter (clk, out) ;
input clk;
output wire [1:0] out;
reg [1:0]temp=2'b00;
always@ (negedge clk)
begin
if(temp == 2'b11) temp <= 2'b00;
else temp <= temp+1'b1;
end
assign out=temp;
endmodule