module data_reg(clk, en, in, cout) ;
input clk, en;
input [7:0] in;
output [7:0] cout=8'b00000000;
reg [7:0] cout;
always@ (negedge clk)
begin
 if(en == 1)
cout <= in;
else ;
end
endmodule