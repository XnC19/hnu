module con_signal(
	input [7:0] ir,
	input add,sub,jmp,movi,mova,movb,movc,movd,in1,out1,halt,sm,jg,g,
	output reg ram_wr,sm_en,ir_ld,ram_re,reg_we,pc_ld,pc_in,out_en,mux_s,au_en,gf_en,in_en,
	output reg [1:0] reg_sr,reg_dr,s,
	output reg [3:0] au_ac
);
always @(*)
	begin
		sm_en=~halt;
		ir_ld=~sm;
		ram_re=(~sm)|movc|movi;
		ram_wr=movb;
		pc_ld=jmp|(jg&g);
		pc_in=(~sm)|movi;
		reg_we=mova|movc|movd|add|sub|in1|movi;
		au_en=mova|movb|add|sub|out1;
		gf_en=sub;
		in_en=in1;
		out_en=out1;
		au_ac[3:0]=ir[7:4];
		mux_s=mova|movc|add|sub|in1|movi;
		reg_dr=ir[3:2];
		reg_sr=ir[1:0];
		if(movc) s=2'b01;
		else if(movb) s=2'b10;
		else s=2'b00;
	end
endmodule
		
		